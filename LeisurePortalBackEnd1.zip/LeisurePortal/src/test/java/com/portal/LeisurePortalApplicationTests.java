package com.portal;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class LeisurePortalApplicationTests {

//	@Test
	public void contextLoads() {
	}

}
