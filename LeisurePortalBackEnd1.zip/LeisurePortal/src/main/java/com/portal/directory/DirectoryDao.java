package com.portal.directory;

import java.util.List;

import javax.persistence.EntityManagerFactory;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class DirectoryDao {

	@Autowired
	EntityManagerFactory entityManagerFactory;
	public List<?> getAllEmployeesList() {
		Session session = null;
		List<?> employeeList = null;
		try {
			session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
			session.beginTransaction();
			employeeList = session.createQuery("FROM EmployeeList").list();
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			if(null != session && session.isOpen()) {
				session.getTransaction().rollback();
			}
		} finally {
			if(null != session && session.isOpen()) {
				session.close();
			}
		}
		return employeeList;
		
//		Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
//        CriteriaBuilder builder = session.getCriteriaBuilder();
//        CriteriaQuery criteria = builder.createQuery(EmployeeList.class);
//        Root contactRoot = criteria.from(EmployeeList.class);
//        criteria.select(contactRoot);
//        return session.createQuery(criteria).getResultList();
	}
	
	
}
