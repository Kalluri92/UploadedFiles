package com.portal.directory;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "employee_list")
public class EmployeeList {

	@Id
	@Column(name = "employee_id")
	private String employeeId;

	public EmployeeList(String employeeId) {
		this.employeeId = employeeId;
	}

	public EmployeeList() {
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	
}
