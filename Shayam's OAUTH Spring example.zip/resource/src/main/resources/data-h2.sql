INSERT INTO NOTE(TITLE, CONTENT) VALUES
('Must do today','Lorem ipsum dolor sit amet, consectetur adipiscing elit. In volutpat, turpis vitae ultrices maximus, orci leo condimentum nunc, id faucibus lectus lacus id arcu.'),
('Pentatonic scale practice routine','Ut feugiat leo et commodo tincidunt. Nulla feugiat interdum tincidunt. Morbi pellentesque odio ut leo rhoncus, eget cursus nisl varius. Suspendisse tellus purus, lacinia ut vestibulum vitae, consequat vel dui.'),
('Book review: Chasm City by Alastair Reynolds','Nunc egestas, orci sit amet venenatis sagittis, nisi erat suscipit ipsum, ut ullamcorper felis quam interdum turpis. Suspendisse facilisis quis risus id feugiat.'),
('My zombie apocalypse novel','Ut facilisis dictum libero non consectetur. Cras tempor risus metus, nec ullamcorper risus varius a.'),
('Java reading list','Maecenas tristique ut nisi molestie rutrum. Quisque aliquet auctor mauris in mattis. Nunc nisl lacus, placerat id bibendum vitae, mattis tristique ante.');