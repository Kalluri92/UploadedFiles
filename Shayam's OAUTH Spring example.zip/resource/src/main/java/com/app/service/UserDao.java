/**
 * 
 *//*
package com.app.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.app.model.Users;

*//**
 * @author shysatya
 *
 *//*
@Component
public interface UserDao {

	
		Users findById(int id);     
	  
	    void save(Users user);
	     
	    void deleteById(int id);
	     
	    List<Users> findAllUsers();
}
*/