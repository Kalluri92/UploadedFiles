/**
 * 
 *//*
package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.model.Bussiness;

*//**
 * @author shysatya
 *
 *//*
@Component
public class BusinessServiceImpl implements BusinessService{

	@Autowired
	BusinessDAO busDAO;
	
	@Override
	public void saveBusiness(Bussiness bus) {
		busDAO.save(bus);
		
	}

}
*/