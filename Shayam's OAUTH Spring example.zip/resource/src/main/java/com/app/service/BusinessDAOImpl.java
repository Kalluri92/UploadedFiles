/*package com.app.service;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.model.Bussiness;

@Repository("busDAO")
@Transactional
public class BusinessDAOImpl extends AbstractDao<Integer, Bussiness> implements BusinessDAO{

	@Override
	public Bussiness findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(Bussiness bussiness) {
		persist(bussiness);
	}

	@Override
	public void deleteById(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Bussiness> findAllBussiness() {
		// TODO Auto-generated method stub
		return null;
	}

}
*/