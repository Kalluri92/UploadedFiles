/*package com.app.service;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.model.Users;

 
 
 
@Repository("userDao")
@Transactional
public class UserDaoImpl extends AbstractDao<Integer, Users> implements UserDao {
 
    static final Logger logger = LoggerFactory.getLogger(UserDaoImpl.class);

	@Override
	public Users findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(Users user) {
		persist(user);
	}

	@Override
	public void deleteById(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Users> findAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}
     

 
}*/