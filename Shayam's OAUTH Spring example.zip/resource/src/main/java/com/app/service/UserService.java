package com.app.service;

import org.springframework.stereotype.Component;

import com.app.model.Users;

@Component
public interface UserService {
	
	void saveUsers(Users user);
	

}
