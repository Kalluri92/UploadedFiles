	var token = $("meta[name='_csrf']").attr("content");
	var header = $("meta[name='_csrf_header']").attr("content");
function doPost() {

	var title =$('#title').val();
	var content =$('#content').val();
	var params = {"title":title,"content":content,"_csrf":token,"action":""}
	$.ajax({
		type: "POST",
		url: "/add",
		
		beforeSend:function(request){
			  request.setRequestHeader(header, token);
		  },
		data: params,							  
		success:function(data){
			
			console.log(data);
		}
	});
 }

 function doGet() {
		
	
		$.ajax({
			type: "GET",
			url: "/getUsers",
			beforeSend:function(request){
				  request.setRequestHeader(header, token);
			  },
			data: "",							  
			success:function(data){
				
				console.log(data);
			}
		});
	 }
function addUser(){
		var data={
				
				"username":"Shyam",
				"email":"shyam@shyam.com",
				"password":"sss@123"
		}
		
			$.ajax({
				type: "POST",
				url: "/addNewUser",
				contentType:"application/json",
				beforeSend:function(request){
					  request.setRequestHeader(header, token);
				  },
				data: JSON.stringify(data),							  
				success:function(data){
					
					console.log(data);
				}
			});
}

