package com.portal.fileshare;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class FileshareController {

}
