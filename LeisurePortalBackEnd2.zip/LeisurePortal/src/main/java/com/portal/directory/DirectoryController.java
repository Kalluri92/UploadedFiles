package com.portal.directory;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DirectoryController {

	@Autowired
	DirectroyService directroyService;
	
	@GetMapping("/getAll")
	public List<?> getAllEmployeesList(){
		return directroyService.getAllEmployeesList();
	}
	@GetMapping("/getPersonalInfo/{employeeId}")
	public EmployeePersonalInfo getPersonalInfo(@PathVariable("employeeId") String employeeId){
		return directroyService.getPersonalInfo(employeeId);
	}
	@GetMapping("/getOfficalInfo/{employeeId}")
	public EmployeeOfficalInfo getAllEmployeesList(@PathVariable("employeeId") String employeeId){
		return directroyService.getOfficalInfo(employeeId);
	}
}
