package com.portal.directory;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "employee_offical_info")
public class EmployeeOfficalInfo {

	@Id
	@Column(name = "employee_id")
	private String employeeId;

	@Column(name = "project_name")
	private String projectName;

	@Column(name = "project_code")
	private String projectCode;

	@Column(name = "account_name")
	private String accountName;

	@Column(name = "account_code")
	private String accountCode;

	@Column(name = "team_name")
	private String teamName;

	@Column(name = "team_code")
	private String teamCode;

	@Column(name = "role_in_project")
	private String roleInProject;

	@Column(name = "project_sub_group")
	private String subGroupOfProject;

	@Column(name = "reports_to")
	private String reportsTo;

	@Column(name = "optional_data")
	private String optionalData;

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getProjectCode() {
		return projectCode;
	}

	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountCode() {
		return accountCode;
	}

	public void setAccountCode(String accountCode) {
		this.accountCode = accountCode;
	}

	public String getTeamCode() {
		return teamCode;
	}

	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}

	public String getRoleInProject() {
		return roleInProject;
	}

	public void setRoleInProject(String roleInProject) {
		this.roleInProject = roleInProject;
	}

	public String getReportsTo() {
		return reportsTo;
	}

	public void setReportsTo(String reportsTo) {
		this.reportsTo = reportsTo;
	}

	public String getOptionalData() {
		return optionalData;
	}

	public void setOptionalData(String optionalData) {
		this.optionalData = optionalData;
	}

	public String getSubGroupOfProject() {
		return subGroupOfProject;
	}

	public void setSubGroupOfProject(String subGroupOfProject) {
		this.subGroupOfProject = subGroupOfProject;
	}
}
