package com.portal.directory;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "employee_personal_info")
public class EmployeePersonalInfo {

	@Id
	@Column(name = "employee_id")
	private String employeeId;

	@Column(name = "employee_designation")
	private String employeeDesignation;

	@Column(name = "employee_designation_code")
	private String employeeDesignationCode;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "office_email_id")
	private String officeEmailId;

	@Column(name = "personal_email_id")
	private String personalEmailId;

	@Column(name = "office_phone_number")
	private String officePhoneNumber;

	@Column(name = "personal_phone_number")
	private String personalPhoneNumber;

	@Column(name = "blood_group")
	private String bloodGroup;

	@Column(name = "emergency_info")
	private String emergencyContactInfo;

	@Column(name = "address")
	private String address;

	@Column(name = "date_of_birth")
	private Date dateOfBirth;

	@Column(name = "date_of_join")
	private Date dateOfJoin;

	@Column(name = "marriage_anniversary")
	private Date marriageAnniversiary;

	@Column(name = "relation")
	private String relation;

	@Column(name = "achivements")
	private String achivements;

	@Column(name = "hobbies")
	private String hobbies;

	@Column(name = "optional_data")
	private String optionalData;

	public String getOptionalData() {
		return optionalData;
	}

	public void setOptionalData(String optionalData) {
		this.optionalData = optionalData;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeDesignation() {
		return employeeDesignation;
	}

	public void setEmployeeDesignation(String employeeDesignation) {
		this.employeeDesignation = employeeDesignation;
	}

	public String getEmployeeDesignationCode() {
		return employeeDesignationCode;
	}

	public void setEmployeeDesignationCode(String employeeDesignationCode) {
		this.employeeDesignationCode = employeeDesignationCode;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getOfficeEmailId() {
		return officeEmailId;
	}

	public void setOfficeEmailId(String officeEmailId) {
		this.officeEmailId = officeEmailId;
	}

	public String getPersonalEmailId() {
		return personalEmailId;
	}

	public void setPersonalEmailId(String personalEmailId) {
		this.personalEmailId = personalEmailId;
	}

	public String getOfficePhoneNumber() {
		return officePhoneNumber;
	}

	public void setOfficePhoneNumber(String officePhoneNumber) {
		this.officePhoneNumber = officePhoneNumber;
	}

	public String getPersonalPhoneNumber() {
		return personalPhoneNumber;
	}

	public void setPersonalPhoneNumber(String personalPhoneNumber) {
		this.personalPhoneNumber = personalPhoneNumber;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public String getEmergencyContactInfo() {
		return emergencyContactInfo;
	}

	public void setEmergencyContactInfo(String emergencyContactInfo) {
		this.emergencyContactInfo = emergencyContactInfo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Date getDateOfJoin() {
		return dateOfJoin;
	}

	public void setDateOfJoin(Date dateOfJoin) {
		this.dateOfJoin = dateOfJoin;
	}

	public Date getMarriageAnniversiary() {
		return marriageAnniversiary;
	}

	public void setMarriageAnniversiary(Date marriageAnniversiary) {
		this.marriageAnniversiary = marriageAnniversiary;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public String getAchivements() {
		return achivements;
	}

	public void setAchivements(String achivements) {
		this.achivements = achivements;
	}

	public String getHobbies() {
		return hobbies;
	}

	public void setHobbies(String hobbies) {
		this.hobbies = hobbies;
	}
}
