package com.portal.directory;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "employee_list")
public class EmployeeList {

	@Id
	@Column(name = "employee_id")
	private String employeeId;

	@Column(name = "optional_data")
	private String optionalData;

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getOptionalData() {
		return optionalData;
	}

	public void setOptionalData(String optionalData) {
		this.optionalData = optionalData;
	}
	
	
}
