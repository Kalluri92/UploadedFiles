package com.portal.directory;

import java.util.List;

import javax.persistence.EntityManagerFactory;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class DirectoryDao {

	@Autowired
	EntityManagerFactory entityManagerFactory;

	public List<?> getAllEmployeesList() {
		Session session = null;
		List<?> employeeList = null;
		try {
			session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
			session.beginTransaction();
			employeeList = session.createQuery("FROM EmployeeList").list();
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			if (null != session && session.isOpen()) {
				session.getTransaction().rollback();
			}
		} finally {
			if (null != session && session.isOpen()) {
				session.close();
			}
		}
		return employeeList;
	}

	public EmployeePersonalInfo getPersonalInfo(String employeeId) {
		Session session = null;
		EmployeePersonalInfo epInfo = null;
		try {
			session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
			session.beginTransaction();
			epInfo = session.get(EmployeePersonalInfo.class, employeeId);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			if (null != session && session.isOpen()) {
				session.getTransaction().rollback();
			}
		} finally {
			if (null != session && session.isOpen()) {
				session.close();
			}
		}
		return epInfo;
	}

	public EmployeeOfficalInfo getOfficalInfo(String employeeId) {
		Session session = null;
		EmployeeOfficalInfo eoInfo = null;
		try {
			session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
			session.beginTransaction();
			eoInfo = session.get(EmployeeOfficalInfo.class, employeeId);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			if (null != session && session.isOpen()) {
				session.getTransaction().rollback();
			}
		} finally {
			if (null != session && session.isOpen()) {
				session.close();
			}
		}
		return eoInfo;
	}

}
