import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { DirectoryRoutingModule } from './directory-routing.module';
import { HomeComponent } from './home/home.component';
import { MyInfoComponent } from './my-info/my-info.component';
import { ViewAllComponent } from './view-all/view-all.component';

// Prime Ng Related Components Import
import { InputTextModule } from 'primeng/components/inputtext/inputtext';
import { InputTextareaModule } from 'primeng/components/inputtextarea/inputtextarea';
import { CalendarModule } from 'primeng/components/calendar/calendar';
import { AutoCompleteModule } from 'primeng/components/autocomplete/autocomplete';
import { ButtonModule } from 'primeng/components/button/button';
import { SplitButtonModule } from 'primeng/components/splitbutton/splitbutton';
import { DropdownModule } from 'primeng/components/dropdown/dropdown';
import { PasswordModule } from 'primeng/components/password/password';
import { ListboxModule } from 'primeng/components/listbox/listbox';
import { RadioButtonModule } from 'primeng/components/radiobutton/radiobutton';
import { DialogModule } from 'primeng/components/dialog/dialog';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    // Router Module.
    DirectoryRoutingModule,
    // From Here Prime Ng Components Import
    InputTextModule,
    InputTextareaModule,
    CalendarModule,
    AutoCompleteModule,
    SplitButtonModule,
    PasswordModule,
    DropdownModule,
    ListboxModule,
    RadioButtonModule,
    DialogModule
  ],
  declarations: [HomeComponent, MyInfoComponent, ViewAllComponent],
  bootstrap: [HomeComponent]
})
export class DirectoryModule { }
