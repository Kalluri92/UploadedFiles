import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { MyInfoComponent } from './my-info/my-info.component';
import { ViewAllComponent } from './view-all/view-all.component';
import { FormsModule } from '@angular/forms';
const routes: Routes = [
   { path : '', component : HomeComponent, children : [
    {path : '', redirectTo : 'viewAll'},
     {path : 'myInfo', component : MyInfoComponent},
     {path : 'viewAll', component : ViewAllComponent}
   ]}
];

@NgModule({
  imports: [
    FormsModule,
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class DirectoryRoutingModule { }
