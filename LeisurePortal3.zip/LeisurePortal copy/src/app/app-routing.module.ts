import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppHomeComponent } from './app-home.component';

const routes: Routes = [
  {
    path: 'fileShare',
    loadChildren: 'app/fileshare/fileshare.module#FileshareModule'
  },
  {
    path: 'directory',
    loadChildren: 'app/directory/directory.module#DirectoryModule'
  },
  {
    path: '',
    component : AppHomeComponent,
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
