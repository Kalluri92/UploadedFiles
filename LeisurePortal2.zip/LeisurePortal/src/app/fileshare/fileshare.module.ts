import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FileshareRoutingModule } from './fileshare-routing.module';
import { HomeComponent } from './home/home.component';
import { DownloadComponent } from './download/download.component';
import { UploadComponent } from './upload/upload.component';

@NgModule({
  imports: [
    CommonModule,
    FileshareRoutingModule
  ],
  declarations: [HomeComponent, DownloadComponent, UploadComponent],
  bootstrap: [HomeComponent]
})
export class FileshareModule { }
