import { Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-my-info',
  templateUrl: './my-info.component.html',
  styleUrls: ['./my-info.component.css']
})
export class MyInfoComponent implements OnInit {

  display = false;
  val = '';
  selectedOption = '';
  selectedCity = '';
  splitMenuItems = '';
  country = '';
  date = '';
  constructor() { }

  ngOnInit() {
  }
  showDialog() {
    this.display = true;
  }

}
